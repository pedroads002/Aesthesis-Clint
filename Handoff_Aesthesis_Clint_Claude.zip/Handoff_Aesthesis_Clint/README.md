# Pacote de transferência — Aesthesis Clinic / Clint

Arquivos:
- 00_LEIA-ME_E_CONTEXTO.md
- 01_ESTRATEGIA-COMERCIAL.md
- 02_ARQUITETURA-CLINT.md
- 03_HISTORICO-DECISOES-E-ALTERACOES.md
- 04_STATUS-PENDENCIAS-E-ROADMAP.md
- 05_REGRAS-DO-AGENTE.md
- ESTADO_ATUAL.md
- PROMPTS_PARA_CLAUDE.md

Importante: conteúdo compilado de contexto histórico disponível, sem auditoria atual da Clint e sem todas as fontes primárias. Divergências foram mantidas como desconhecidas, não resolvidas por inferência.
